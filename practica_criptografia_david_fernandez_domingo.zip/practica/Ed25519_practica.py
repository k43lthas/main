import ed25519
import os
my_path = os.path.abspath(os.getcwd())

privatekey = open("C:\\Users\\VM\\Documents\\pythoncrypto\\codigo fuente\\practica\\ed25519-priv","rb").read()

signedKey = ed25519.SigningKey(privatekey)
msg = bytes('El equipo está preparado para seguir con el proceso, necesitaremos más recursos.','utf8')
signature = signedKey.sign(msg, encoding='hex')

print("Firma Generada:", signature)


