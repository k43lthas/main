import json
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

#Cifrado
textoPlano_bytes = bytes('He descubierto el error y no volveré a hacerlo mal', 'UTF-8')
clave = bytes.fromhex('E2CFF885901B3449E9C448BA5B948A8C4EE322152B3F1ACFA0148FB3A426DB74')
#nonce = bytes.fromhex('9Yccn/f5nJJhAt2S')
nonce = b64decode('9Yccn/f5nJJhAt2S')

datos_asociados_bytes = bytes("identificador", "UTF-8")
cipher = AES.new(clave, AES.MODE_GCM,nonce=nonce)

#Esto es importante hacerlo en orden. 
cipher.update(datos_asociados_bytes)

#Vamos a cifrar y autenticar.
texto_cifrado_bytes, mac = cipher.encrypt_and_digest(textoPlano_bytes)
texto_cifrado_b64 = b64encode(texto_cifrado_bytes).decode('utf-8')
print("texto_cifrado_bytes_hex: " + texto_cifrado_bytes.hex())
print("texto_cifrado_b64: " + texto_cifrado_b64)

print("tag: " + mac.hex())


#Descifrado

try:

    tag_desc_bytes = bytes.fromhex("bd2351ac0ccf02e9a9b049eea0c4dcaf")
    datos_asociados_desc_bytes = bytes("identificador", "UTF-8")
    cipher = AES.new(clave, AES.MODE_GCM, nonce=nonce)
    cipher.update(datos_asociados_desc_bytes)
    mensaje_des_bytes = cipher.decrypt_and_verify(texto_cifrado_bytes,tag_desc_bytes)
    print("El texto en claro es: ", mensaje_des_bytes.decode("utf-8"))


except (ValueError, KeyError) as error:
    print('Problemas para descifrar....')
    print("El motivo del error es: ", error) 