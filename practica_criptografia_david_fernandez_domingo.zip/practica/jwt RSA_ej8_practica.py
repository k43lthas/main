from ssl import VerifyFlags
import jwt

#Clave publica y privada
public_key = open("C:\\Users\\VM\Documents\\pythoncrypto\\codigo fuente\\Hashing y Authentication\\public.pem").read()
private_key = open("C:\\Users\\VM\\Documents\\pythoncrypto\\codigo fuente\\Hashing y Authentication\\private.pem").read()


#Codificamos el POST
print("================================")
encoded = jwt.encode({"idUsuario": "1", "usuario": "José Manuel Barrio Barrio", "tarjeta": "4231212345676891"}, private_key, algorithm="RS256")
print(encoded)
print("================================")

#Comprovamos la firma con la clave publica
decode = jwt.decode(encoded, public_key,algorithms="RS256", options={"verify_signature": True})
print(decode)
print("================================")
