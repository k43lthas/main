from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256

import os
my_path = os.path.abspath(os.getcwd())

fichero_fpriv = my_path + "\\codigo fuente\\practica\\clave-rsa-oaep-priv.pem"
fpriv=open(fichero_fpriv,'r')
keypr= RSA.import_key(fpriv.read())

#Mensaje a descifrar
mensajeCifrado = bytes('El equipo está preparado para seguir con el proceso, necesitaremos más recursos.','utf8')
decryptor = PKCS1_OAEP.new(keypr, SHA256)
decrypted = decryptor.decrypt(mensajeCifrado)
print('Descifrado: ', decrypted.hex())
